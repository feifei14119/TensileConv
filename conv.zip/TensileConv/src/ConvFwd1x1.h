/*
 ***********************************************************************************************************************
 *
 *  Trade secret of Advanced Micro Devices, Inc.
 *  Copyright (c) 2014-2019, Advanced Micro Devices, Inc., (unpublished)
 *
 *  All rights reserved. This notice is intended as a precaution against inadvertent publication and does not imply
 *  publication or any waiver of confidentiality. The year included in the foregoing notice is the year of creation of
 *  the work.
 *
 **********************************************************************************************************************/
#pragma once 

#include "TensileConvBase.h"
#include "ConvFwd1x1KernelWriter.h"

namespace TensileConv {

#define MAP_KEY_LEN (30)
	typedef struct SaveParamStruct
	{
		char key[MAP_KEY_LEN];
		int N, C, H, W, K;
		bool bias; E_Relu relu;
		int PCK_order;
		int c_in_lds_atomic_group;
		int c_in_lds_split_group;
		int c_in_l2_atomic_group;
		int c_in_l2_split_group;
		int k_out_maps;
		int group_size_x;
		double elapsedSec;
	} T_SaveParam;
/************************************************************************/
/* solution ����										                    */
/************************************************************************/
class ConvFwd1x1Problem;
class ConvFwd1x1Solution : public SolutionCtrlBase
{
public:
	ConvFwd1x1Solution(ConvFwd1x1Problem * problem, std::string name = "", LogFile * file = nullptr);
	AutoGen::T_Conv1x1KernelParam KernelParam() { return kernelParam; }
	void GetBestKernel();
	size_t SignalSize() { return size_sig; }
	size_t L2SplitSize() { return size_l2; }
	size_t DebugSize() { return size_dbg; }

private:
	float *h_sig, *h_l2, *h_dbg;
	cl_mem d_in, d_wei, d_bias, d_out, d_sig, d_l2, d_dbg;
	float negSlop;
	size_t size_sig = 0, size_l2 = 0, size_dbg = 0;

protected:
	ConvFwd1x1Problem * problem;
	AutoGen::T_Conv1x1KernelParam kernelParam;
	AutoGen::KernelWriterConv1x1 * kernelWriter;

	E_ReturnState generateSolutionParamSpace();
	E_ReturnState getKernelParam();
	E_ReturnState getBestKernelParam();
	E_ReturnState generateKernel();
	E_ReturnState prepareKernelArgs();
	void getBackResult();
	void releaseDevMem();
};

/************************************************************************/
/* solver ����															*/
/************************************************************************/
class ConvFwd1x1Solver : public SolverCtrlBase
{
public:
	ConvFwd1x1Solver(ConvFwd1x1Problem * problem, LogFile * file = nullptr);
	
protected:
	ConvFwd1x1Problem * problem;
	void generateSolver();
};

/************************************************************************/
/* problem ����															*/
/************************************************************************/
class ConvFwd1x1Problem : public ProblemCtrlBase
{
public:
	ConvFwd1x1Problem(std::string name = "", LogFile * file = nullptr);
	~ConvFwd1x1Problem() 
	{ 
		delete solver;
	}

	void TuneProblem();
	void TuneProblem(int W, int H, int C, int K, int N, int UV, bool isBias, int Relu, int TuneMethod);

	int N() { return batch; }
	int W() { return in_width; } int H() { return in_height; }
	int C() { return in_chan; } int K() { return out_chan; }
	int X() { return wei_width; } int Y() { return wei_height; }
	int R() { return pad_x; } int S() { return pad_y; }
	int U() { return stride_x; } int V() { return stride_y; }
	int OutW() { return out_width; } int OutH() { return out_height; }
	int EnBias() { return enBias; } 
	E_Relu Relu() { return relu; }
	float NegSlop() { return negSlop; }

	void verifyDevCompute();

	float* h_in, *h_wei, *h_bias, *h_out, *out_ref;
	size_t size_in, size_wei, size_bias, size_out;

private:
	void generateProblem();
	void initHostParam();
	void runHostCompute();
	void releaseHostParam();
	void caculateTheoryPerformance();

	int batch;					// batch size
	int in_width, in_height;	// input size
	int in_chan, out_chan;		// input channel / output feature
	int wei_width, wei_height;	// weight size
	int pad_x, pad_y;			// padding 
	int stride_x, stride_y;		// stride
	int out_width, out_height;	// output size
	bool enBias;
	E_Relu relu;
	float negSlop;
};

extern void SetDatabasePath(std::string path);
extern std::string GetDatabasePath();

}


