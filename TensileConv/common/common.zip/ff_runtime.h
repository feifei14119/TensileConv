﻿#pragma once

#include <stdarg.h>

#include "ff_utils.h"
#include <CL/opencl.h>

